const quizData = [
    {
        question: "What does HTML stand for?",
        options: ["HyperText Markup Language", "HyperTool Markup Language", "HighText Markup Language", "HyperText Machine Language"],
        correctAnswer: 0
    },
    {
        question: "Which of the following is used to style a webpage?",
        options: ["HTML", "CSS", "JavaScript", "PHP"],
        correctAnswer: 1
    },
    {
        question: "Which tag is used to define a hyperlink in HTML?",
        options: ["<link>", "<href>", "<a>", "<url>"],
        correctAnswer: 2
    },
    {
        question: "What is the correct syntax to add a comment in JavaScript?",
        options: ["// This is a comment", "/* This is a comment */", "<!-- This is a comment -->", "Both A and B"],
        correctAnswer: 3
    },
    {
        question: "Which property is used to change the background color in CSS?",
        options: ["background-color", "color", "bgcolor", "background-image"],
        correctAnswer: 0
    },
    {
        question: "Which HTML element is used to define an ordered list?",
        options: ["<ul>", "<ol>", "<li>", "<list>"],
        correctAnswer: 1
    },
    {
        question: "What does the CSS property z-index control?",
        options: ["Font size", "Element visibility", "Stack order of elements", "Element alignment"],
        correctAnswer: 2
    },
    {
        question: "Which of the following is the correct way to link an external JavaScript file in HTML?",
        options: ["<script src='file.js'>", "<js src='file.js'>", "<link src='file.js'>", "<javascript src='file.js'>"],
        correctAnswer: 0
    },
    {
        question: "Which of these is NOT a valid data type in JavaScript?",
        options: ["String", "Boolean", "Integer", "Undefined"],
        correctAnswer: 2
    },
    {
        question: "Which of the following is used to select an element with the class 'example' in JavaScript?",
        options: ["document.getElementByClass('example')", "document.getElementsByClass('example')", "document.querySelector('.example')", "document.getElementById('example')"],
        correctAnswer: 2
    }
];

let currentQuestionIndex = 0;
let score = 0;
let timer;
let timeLeft = 360; // 6 minutes timer (360 seconds)
let answeredQuestions = [];

function loadQuestion() {
    const question = quizData[currentQuestionIndex];
    const quizDiv = document.getElementById("quiz");
    const nextButton = document.getElementById("next");
    const previousButton = document.getElementById("previous");

    // Display the question and options
    quizDiv.innerHTML = `
        <h2>${question.question}</h2>
        <div id="options">
            ${question.options.map((option, index) => `
                <div>
                    <input type="radio" name="option" value="${index}" id="option-${index}">
                    <label for="option-${index}">${option}</label>
                </div>
            `).join('')}
        </div>
    `;

    // Reset radio buttons to ensure no option is selected initially
    const radioButtons = document.querySelectorAll('input[name="option"]');
    radioButtons.forEach(button => button.checked = false);

    // Show/Hide next/previous buttons
    nextButton.style.display = "inline-block";
    previousButton.style.display = currentQuestionIndex > 0 ? "inline-block" : "none";

    // Start the timer if this is the first question
    if (currentQuestionIndex === 0) {
        startTimer();
    }

    // Update answered questions list for navigation
    updateAnsweredQuestionsList();
}

function nextQuestion() {
    const selectedOption = document.querySelector('input[name="option"]:checked');
    if (selectedOption) {
        const selectedAnswer = parseInt(selectedOption.value);
        if (selectedAnswer === quizData[currentQuestionIndex].correctAnswer) {
            score++;
        }
        answeredQuestions.push(currentQuestionIndex);
    }

    currentQuestionIndex++;

    if (currentQuestionIndex < quizData.length) {
        loadQuestion();
    } else {
        endQuiz();
    }
}

function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        loadQuestion();
    }
}

function startTimer() {
    timer = setInterval(() => {
        if (timeLeft > 0) {
            timeLeft--;
            document.getElementById("time").textContent = timeLeft;
        } else {
            clearInterval(timer);
            nextQuestion(); // Automatically move to the next question when time is up
        }
    }, 1000);
}

function endQuiz() {
    document.getElementById("quiz").innerHTML = `<h2>Quiz Over!</h2>`;
    document.getElementById("score").textContent = `Your score: ${score} out of ${quizData.length}`;
    document.getElementById("timer").style.display = "none";
    document.getElementById("next").style.display = "none";
    document.getElementById("previous").style.display = "none";
    document.getElementById("finish").style.display = "none";
}

function updateAnsweredQuestionsList() {
    const answeredDiv = document.getElementById("answered-questions");
    answeredDiv.innerHTML = `<h3>Answered Questions:</h3>`;
    answeredQuestions.forEach(index => {
        answeredDiv.innerHTML += `<a href="javascript:void(0)" onclick="goToQuestion(${index})">Question ${index + 1}</a><br>`;
    });
}

function goToQuestion(index) {
    currentQuestionIndex = index;
    loadQuestion();
}

// Load the first question when the app starts
loadQuestion();


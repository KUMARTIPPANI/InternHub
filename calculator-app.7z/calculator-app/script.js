let currentInput = '';  // Stores current input in the display
let previousInput = ''; // Stores the last entered value for operations
let operator = '';      // Stores the current operator (+, -, *, /)

/* Function to update the display */
function updateDisplay(value) {
    document.getElementById('display').value = value;
}

/* Function to handle button clicks */
function handleButtonClick(value) {
    if (value === 'C') {
        // Clear the display
        currentInput = '';
        previousInput = '';
        operator = '';
        updateDisplay(currentInput);
    } else if (value === '=') {
        // Perform the calculation when '=' is pressed
        if (previousInput !== '' && operator !== '') {
            let result;
            switch (operator) {
                case '+':
                    result = parseFloat(previousInput) + parseFloat(currentInput);
                    break;
                case '-':
                    result = parseFloat(previousInput) - parseFloat(currentInput);
                    break;
                case '*':
                    result = parseFloat(previousInput) * parseFloat(currentInput);
                    break;
                case '/':
                    if (currentInput !== '0') {
                        result = parseFloat(previousInput) / parseFloat(currentInput);
                    } else {
                        result = 'Error';
                    }
                    break;
            }
            currentInput = result.toString();
            updateDisplay(currentInput);
            previousInput = '';
            operator = '';
        }
    } else if (['+', '-', '*', '/'].includes(value)) {
        // If an operator is clicked, save the current input and operator
        if (currentInput !== '') {
            previousInput = currentInput;
            currentInput = '';
            operator = value;
        }
    } else {
        // Append digits and decimal point to current input
        currentInput += value;
        updateDisplay(currentInput);
    }
}

/* Add event listeners to all buttons */
const buttons = document.querySelectorAll('.btn');
buttons.forEach(button => {
    button.addEventListener('click', () => {
        handleButtonClick(button.getAttribute('data-value'));
    });
});

const apiKey = '208866b57b0081c71c896b0201f0c4ae'; //  OpenWeatherMap API key

// Function to fetch and display the current weather and forecast
async function getWeather() {
    const city = document.getElementById("cityInput").value.trim();
    if (city === '') {
        alert("Please enter a city name.");
        return;
    }

    try {
        // Fetch the current weather
        const currentWeatherResponse = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`);
        const currentWeatherData = await currentWeatherResponse.json();

        // Check for invalid city name
        if (currentWeatherData.cod === '404') {
            alert('City not found. Please try again.');
            return;
        }

        // Display current weather data
        const temperature = currentWeatherData.main.temp;
        const humidity = currentWeatherData.main.humidity;
        const condition = currentWeatherData.weather[0].description;
        document.getElementById('temperature').textContent = `Temperature: ${temperature}°C`;
        document.getElementById('humidity').textContent = `Humidity: ${humidity}%`;
        document.getElementById('condition').textContent = `Condition: ${condition}`;

        // Fetch and display the 5-day forecast
        const forecastResponse = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${apiKey}&units=metric`);
        const forecastData = await forecastResponse.json();
        displayForecast(forecastData);

    } catch (error) {
        console.error(error);
        alert("An error occurred while fetching the weather data.");
    }
}

// Function to display the 5-day forecast
function displayForecast(forecastData) {
    const forecastDetails = document.getElementById('forecastDetails');
    forecastDetails.innerHTML = ''; // Clear previous forecast

    // Display 5-day forecast
    forecastData.list.slice(0, 5).forEach(forecast => {
        const date = new Date(forecast.dt * 1000).toLocaleDateString();
        const temperature = forecast.main.temp;
        const condition = forecast.weather[0].description;

        const forecastElement = document.createElement('div');
        forecastElement.className = 'forecast-day';
        forecastElement.innerHTML = `
            <p><strong>${date}</strong></p>
            <p>Temp: ${temperature}°C</p>
            <p>Condition: ${condition}</p>
        `;

        forecastDetails.appendChild(forecastElement);
    });
}
